create view get_progress_view(full_name, name, percentage, mentor) as
SELECT s.full_name,
       c.name,
       progresses.percentage,
       m.full_name AS mentor
FROM progresses
         JOIN students s ON s.id = progresses.student_id
         JOIN courses c ON c.id = progresses.course_id
         JOIN mentors_courses mc ON c.id = mc.course_id
         JOIN mentors m ON m.id = mc.mentor_id;

alter table get_progress_view
    owner to postgres;

