create function add_transaction(input_user_id integer, category character varying, subcategory character varying, input_amount double precision) returns text
    language plpgsql
as
$$
declare
    v_category_id int;
    v_subcategory_id int;
    begin
    select id, category_id into v_subcategory_id, v_category_id from sub_categories
    where upper(name) = upper(subcategory);

    if v_subcategory_id is null then return 'subcategory not found! please try again';
    end if;

    if v_category_id = 1 then
    Update budgets set amount = amount - input_amount where user_id = input_user_id;
    Update wallets set balance = balance - input_amount where user_id = input_user_id;
    elsif v_category_id = 2 then
    Update budgets set amount = amount + input_amount where user_id = input_user_id;
    Update wallets set balance = balance + input_amount where user_id = input_user_id;
    end if;

    INSERT INTO transactions(user_id, wallet_id, category_id, subcategory_id, note, date,
                             amount) values (input_user_id, input_user_id, v_category_id, v_subcategory_id,
                                             null, now(), input_amount);
    return 'successfully done';
    end;
$$;

alter function add_transaction(integer, varchar, varchar, double precision) owner to postgres;

