create procedure transaction_procedure(IN i_passenger_id integer, IN i_airline_id integer, IN i_flight_price double precision)
    language plpgsql
as
$$
declare
begin

    UPDATE passengers
    SET balance = balance - i_flight_price
    WHERE id = i_passenger_id;

    UPDATE airlines
    SET balance = balance + i_flight_price
    WHERE id = i_airline_id;

    insert into transaction_history(passenger_id, airline_id, flight_price) values
                                                                                   (i_passenger_id, i_airline_id, i_flight_price);

end;
$$;

alter procedure transaction_procedure(integer, integer, double precision) owner to postgres;

