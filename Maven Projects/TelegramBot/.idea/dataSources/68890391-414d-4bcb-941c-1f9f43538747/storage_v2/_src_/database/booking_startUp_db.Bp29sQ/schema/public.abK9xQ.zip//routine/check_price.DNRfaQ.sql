create function check_price(i_from_city integer, i_to_city integer, i_date date, i_flight_class character varying)
    returns TABLE(city_from_id character varying, city_to_id character varying, depart_date_time timestamp with time zone, arrival_date_time timestamp with time zone, airline_id character varying, price double precision, flight_class character varying)
    language plpgsql
as
$$
declare
    set_percentage_by_class double precision;
    define_flight_class varchar;
begin
    if upper(i_flight_class) = 'ECONOM' then set_percentage_by_class = 1; define_flight_class = 'ECONOM';
    elsif upper(i_flight_class) = 'COMFORT' then set_percentage_by_class = 1.1; define_flight_class = 'COMFORT';
    elsif upper(i_flight_class) = 'FIRST' then set_percentage_by_class = 1.2; define_flight_class = 'FIRST';
    else set_percentage_by_class = 1; define_flight_class = 'UNKNOWN';
    end if;

return query

    select distinct c.name, c2.name, f.depart_date_time, f.arrival_date_time, a.name,
           f.flight_price * set_percentage_by_class, define_flight_class
    from flights f
    join airlines a on a.id = f.airline_id
    join cities c on c.id = f.city_from_id
    join cities c2 on c2.id = f.city_to_id
    WHERE f.city_from_id = i_from_city AND f.city_to_id = i_to_city AND f.depart_date_time::date = i_date;

    end;
$$;

alter function check_price(integer, integer, date, varchar) owner to postgres;

