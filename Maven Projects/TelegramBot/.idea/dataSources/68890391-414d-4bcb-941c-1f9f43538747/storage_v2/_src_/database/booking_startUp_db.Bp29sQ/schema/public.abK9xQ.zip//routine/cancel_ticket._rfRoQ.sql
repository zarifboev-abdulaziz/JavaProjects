create function cancel_ticket(i_serial_number integer) returns character varying
    language plpgsql
as
$$
declare
    v_airline_id integer;
    v_ticket_price double precision;
    v_passenger_id integer;
begin

    select t.price, f.airline_id, passenger_id into v_ticket_price, v_airline_id, v_passenger_id from tickets t
    join flights f on f.id = t.flight_id
    where t.serial_number = i_serial_number;

    if v_passenger_id is null OR v_ticket_price is null then return 'Ticket not found!';
    end if;

    UPDATE passengers
    SET balance = balance + v_ticket_price
        WHERE id = v_passenger_id;

    update airlines
    set balance = balance - v_ticket_price
    where id = v_airline_id;

    DELETE FROM tickets WHERE serial_number= i_serial_number;

    return 'Successfully canceled!';
end;
$$;

alter function cancel_ticket(integer) owner to postgres;

