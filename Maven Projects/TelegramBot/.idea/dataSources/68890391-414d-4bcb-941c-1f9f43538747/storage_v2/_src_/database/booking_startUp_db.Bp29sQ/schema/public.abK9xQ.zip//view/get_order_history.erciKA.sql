create view get_order_history (full_name, airline, city_from, city_to, price, ticket_serialnum) as
SELECT DISTINCT p.full_name,
                a.name       AS airline,
                cdepart.name AS city_from,
                carrive.name AS city_to,
                order_history.price,
                order_history.ticket_serialnum
FROM order_history
         JOIN passengers p ON order_history.passenger_id = p.id
         JOIN airlines a ON a.id = order_history.airline_id
         JOIN cities cdepart ON order_history.city_from = cdepart.id
         JOIN cities carrive ON order_history.city_to = carrive.id
         JOIN flights f ON order_history.airline_id = f.airline_id;

alter table get_order_history
    owner to postgres;

