create view get_transaction_history(id, sender, receiver, sentamount, date) as
SELECT transaction_history.id,
       pera.full_name AS sender,
       perb.full_name AS receiver,
       transaction_history.sentamount,
       transaction_history.date
FROM transaction_history
         JOIN persons pera ON pera.id = transaction_history.senderid
         JOIN persons perb ON perb.id = transaction_history.receiverid;

alter table get_transaction_history
    owner to postgres;

