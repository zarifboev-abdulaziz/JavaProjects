create function book_ticket(i_passenger_id integer, i_flight_id integer, i_flight_return integer, i_flight_class character varying) returns character varying
    language plpgsql
as
$$
declare
    generated_serial_number integer;
    generated_serial_number_return integer;

    --(v - variable) it is used to define this functions native variables

    v_flight_id integer;
    v_flight_price double precision;
    v_airline_id int;
    v_from_city_id int;
    v_to_city_id int;

    v_flight_id_return integer;
    v_flight_price_return double precision;
    v_airline_id_return int;
    v_from_city_id_return int;
    v_to_city_id_return int;

    v_flight_class_id int;
    v_flight_class_rate double precision;

begin
    select id, rate into v_flight_class_id, v_flight_class_rate from flight_classes where upper(i_flight_class) = name;

    select f.id, f.flight_price, f.airline_id, f.city_from_id, f.city_to_id into v_flight_id,
        v_flight_price, v_airline_id, v_from_city_id, v_to_city_id from flights f
    where f.id = i_flight_id;

    select f.id, f.flight_price, f.airline_id, f.city_from_id, f.city_to_id into v_flight_id_return,
        v_flight_price_return, v_airline_id_return, v_from_city_id_return, v_to_city_id_return from flights f
    where f.id = i_flight_return;

    if v_flight_id is null then return 'Flight not found! Please try again';
    end if;
    if v_flight_id_return is null then return 'Flight not found! Please try again';
    end if;

    INSERT INTO tickets(flight_class_id, price, flight_id, passenger_id) values
        (v_flight_class_id,
         v_flight_price *
         v_flight_class_rate,
         v_flight_id,
         i_passenger_id);

    INSERT INTO tickets(flight_class_id, price, flight_id, passenger_id) values
        (v_flight_class_id,
         v_flight_price_return *
         v_flight_class_rate,
         v_flight_id_return,
         i_passenger_id);

    select serial_number into generated_serial_number from tickets
    where tickets.passenger_id = i_passenger_id AND tickets.flight_id = v_flight_id AND
            tickets.price = v_flight_price * v_flight_class_rate AND tickets.flight_class_id =
                                                                     v_flight_class_id;

    select serial_number into generated_serial_number_return from tickets
    where tickets.passenger_id = i_passenger_id AND tickets.flight_id = v_flight_id_return AND
            tickets.price = v_flight_price_return * v_flight_class_rate AND tickets.flight_class_id =
                                                                            v_flight_class_id;

    INSERT INTO order_history(passenger_id, airline_id, city_from, city_to, price,
                              ticket_serialnum) values (i_passenger_id, v_airline_id,
                                                        v_from_city_id, v_to_city_id,
                                                        v_flight_price * v_flight_class_rate,
                                                        generated_serial_number);

    INSERT INTO order_history(passenger_id, airline_id, city_from, city_to, price,
                              ticket_serialnum) values (i_passenger_id, v_airline_id_return,
                                                        v_from_city_id_return, v_to_city_id_return,
                                                        v_flight_price_return * v_flight_class_rate,
                                                        generated_serial_number_return);

    call transaction_procedure(i_passenger_id,v_airline_id, v_flight_price * v_flight_class_rate);
    call transaction_procedure(i_passenger_id,v_airline_id_return, v_flight_price_return * v_flight_class_rate);

    return 'Successful purchase! ticket serial number for departure - ' ||
           generated_serial_number || ', ticket serial number for return - ' ||
           generated_serial_number_return;

end;
$$;

alter function book_ticket(integer, integer, integer, varchar) owner to postgres;

