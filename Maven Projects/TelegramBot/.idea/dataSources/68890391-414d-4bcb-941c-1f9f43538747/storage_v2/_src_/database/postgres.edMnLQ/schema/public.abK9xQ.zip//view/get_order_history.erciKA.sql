create view get_order_history(id, first_name, name, quantity, date) as
SELECT orders.id,
       customers.first_name,
       products.name,
       orders.quantity,
       orders.date
FROM orders
         JOIN customers ON customers.id = orders.cutomer_id
         JOIN products ON products.id = orders.product_id;

alter table get_order_history
    owner to postgres;

