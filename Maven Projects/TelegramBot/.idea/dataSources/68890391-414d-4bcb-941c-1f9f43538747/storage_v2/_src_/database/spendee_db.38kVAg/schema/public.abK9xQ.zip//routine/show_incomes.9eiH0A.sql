create function show_incomes(i_user_id integer, date_from date, date_to date)
    returns TABLE(income character varying, percent text)
    language plpgsql
as
$$
Declare
    total_amount decimal;
Begin
    select sum(amount)::decimal into total_amount
    from transactions
    where user_id = i_user_id AND category_id = 2 AND date > date_from AND date < date_to;

    return query
    select sc.name AS Income,
           concat(round(sum(100 * transactions.amount)::decimal / (select sum(amount)
                                                                    from transactions
                                                                    where user_id = i_user_id
                                                                      AND category_id = 2 AND
                                                                          date > date_from AND
                                                                          date < date_to)::decimal,
               2), '%') AS
               Percentage
    from transactions
             join sub_categories sc on transactions.subcategory_id = sc.id
    where user_id = i_user_id AND transactions.category_id = 2 AND date > date_from AND date <
                                                                                        date_to
    Group By sc.name
    ;
End;
$$;

alter function show_incomes(integer, date, date) owner to postgres;

