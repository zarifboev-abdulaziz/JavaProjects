create function check_ticket_status(i_serial_number integer)
    returns TABLE(ticket_owner character varying, ticket_serial_number integer, flight_class character varying, price double precision, city_from_id character varying, city_to_id character varying, depart_date_time timestamp with time zone, arrival_date_time timestamp with time zone, airline_id character varying)
    language plpgsql
as
$$
declare
begin
    return query
    SELECT p.full_name, t.serial_number, fc.name, t.price, city_dep.name, city_arr.name,
           f.depart_date_time, f.arrival_date_time, a.name
           from  tickets t
    join passengers p on p.id = t.passenger_id
    join flights f on f.id = t.flight_id
    join cities city_dep on city_dep.id = f.city_from_id
    join cities city_arr on city_arr.id = f.city_to_id
    join airlines a on a.id = f.airline_id
    join flight_classes fc on t.flight_class_id = fc.id

    WHERE t.serial_number = i_serial_number
    ;

end;
$$;

alter function check_ticket_status(integer) owner to postgres;

