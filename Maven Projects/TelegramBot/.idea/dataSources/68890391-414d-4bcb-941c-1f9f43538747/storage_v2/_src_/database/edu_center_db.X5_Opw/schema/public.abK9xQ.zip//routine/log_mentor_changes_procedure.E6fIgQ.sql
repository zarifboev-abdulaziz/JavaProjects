create function log_mentor_changes_procedure() returns trigger
    language plpgsql
as
$$
BEGIN
    if TG_OP = 'INSERT' or TG_OP = 'UPDATE' then
        insert into log_mentor_changes(full_name, changed_on, log_operation)
        values (old.full_name, now(), TG_OP);
        return new;

    elsif TG_OP = 'DELETE' then
        insert into log_mentor_changes(full_name, changed_on, log_operation)
        values (old.full_name, now(), TG_OP);
        return old;
        end if;

    END;
$$;

alter function log_mentor_changes_procedure() owner to postgres;

