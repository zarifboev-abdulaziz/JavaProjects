create function get_expired_products() returns integer
    language plpgsql
as
$$
Declare  
 expired_product_count integer;  
Begin  
   select count(*)   
   into expired_product_count  
   from products  
   where expired_at < now()::date;  
   return expired_product_count;  
End;
$$;

alter function get_expired_products() owner to postgres;

