create function check_price_by_flight(i_from_city character varying, i_to_city character varying, i_date date, i_flight_class character varying)
    returns TABLE(flight_id integer, city_from_id character varying, city_to_id character varying, depart_date_time timestamp with time zone, arrival_date_time timestamp with time zone, airline_id character varying, price text, flight_class character varying)
    language plpgsql
as
$$
declare
    set_percentage_by_class double precision;
    define_flight_class varchar;
    define_from_city varchar;
    define_from_city_id int;
    define_to_city varchar;
    define_to_city_id int;
begin
    if upper(i_flight_class) = 'ECONOM' then set_percentage_by_class = 1; define_flight_class = 'ECONOM';
    elsif upper(i_flight_class) = 'COMFORT' then set_percentage_by_class = 1.1; define_flight_class = 'COMFORT';
    elsif upper(i_flight_class) = 'FIRST' then set_percentage_by_class = 1.2; define_flight_class = 'FIRST';
    else set_percentage_by_class = 1; define_flight_class = 'UNKNOWN';
    end if;

    select name into define_from_city from cities where upper(name) = upper(i_from_city);
    select id into define_from_city_id from cities where upper(name) = upper(i_from_city);
    select name into define_to_city from cities where upper(name) = upper(i_to_city);
    select id into define_to_city_id from cities where upper(name) = upper(i_to_city);

    return query
       select distinct f.id, define_from_city, define_to_city, f.depart_date_time, f
           .arrival_date_time, a.name,
                        '$' || f.flight_price * set_percentage_by_class, define_flight_class
        from flights f
                 join airlines a on a.id = f.airline_id
        WHERE f.city_from_id = define_from_city_id AND f.city_to_id = define_to_city_id AND f.depart_date_time::date = i_date;

end;
$$;

alter function check_price_by_flight(varchar, varchar, date, varchar) owner to postgres;

