create function postpone_ticket(i_serial_number integer, i_flight_id integer) returns text
    language plpgsql
as
$$
declare

    v_city_from_id integer;
    v_city_to_id integer;
    v_airline_id integer;

    v_city_from_id_postpone integer;
    v_city_to_id_postpone integer;
    v_airline_id_postpone integer;

begin

    select f.city_from_id, f.city_to_id, f.airline_id into v_city_from_id, v_city_to_id, v_airline_id from tickets t
    join flights f on f.id = t.flight_id
    where t.serial_number = i_serial_number;


    select f.city_from_id, f.city_to_id, f.airline_id into v_city_from_id_postpone, v_city_to_id_postpone,
        v_airline_id_postpone from flights f where f.id = i_flight_id;

    if v_city_from_id is null OR v_city_from_id_postpone is null then return 'Ticket not found!';
    end if;

    if v_city_from_id != v_city_from_id_postpone then return 'Process failed! Departure city not matched';
    end if;

    if v_city_to_id != v_city_to_id_postpone then return 'Process failed! Arrival city not matched';
    end if;

    if v_airline_id != v_airline_id_postpone then return 'Process failed! Airlines not matched';
    end if;

    update tickets set flight_id = i_flight_id where serial_number = i_serial_number;

   return 'Successfully delayed!';
end
$$;

alter function postpone_ticket(integer, integer) owner to postgres;

