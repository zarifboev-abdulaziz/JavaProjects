package com.example.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.LocalTime;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class LoginEntity {

    @Id
    private String chatId;
    private String phoneNumber;
    private String pass1;
    private String pass2;
    private int step = 1;
    private LocalTime lastAction;
}
