package com.example.controller;

import com.example.configuration.BotConfiguration;
import com.example.entity.LoginEntity;
import com.example.entity.User;
import com.example.repository.LoginRepo;
import com.example.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendDocument;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Contact;
import org.telegram.telegrambots.meta.api.objects.InputFile;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.time.LocalTime.now;
import static java.time.temporal.ChronoUnit.MINUTES;

@RequiredArgsConstructor
@Component
public class MyBotService extends TelegramLongPollingBot {

    private static final String filePath = "/home/shoh/d_doc/backUp/database/";

    private final BotConfiguration botConfiguration;
    private final UserRepository userRepository;
    private final LoginRepo loginRepo;


    @Override
    public String getBotUsername() {
        return this.botConfiguration.getUsername();
    }

    @Override
    public String getBotToken() {
        return this.botConfiguration.getToken();
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage()) {
            Message message = update.getMessage();
            String chatId = message.getChatId().toString();
            SendMessage sendMessage = new SendMessage();
            sendMessage.setChatId(chatId);
            LoginEntity loginEntity = getLoginEntity(update);
            if (message.hasText()) {
                String text = message.getText();

                if (text.equals("/start")) {
                    String chatId1 = loginEntity.getChatId();
                    Optional<User> byChatId = userRepository.findByChatId(chatId1);
                    if (byChatId.isPresent()) {
                        User user = byChatId.get();
                        user.setLogin(false);
                        user.setChatId(null);
                        userRepository.save(user);
                    }
                    loginRepo.delete(loginEntity);
                    loginEntity = getLoginEntity(update);
                }


                if (loginEntity.getStep() == 1) {
                    ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
                    replyKeyboardMarkup.setResizeKeyboard(true);
                    replyKeyboardMarkup.setSelective(true);
                    replyKeyboardMarkup.setOneTimeKeyboard(true);
                    List<KeyboardRow> keyboardRows = new ArrayList<>();
                    KeyboardRow keyboardButtons = new KeyboardRow();
                    KeyboardButton keyboardButton = new KeyboardButton();
                    keyboardButton.setRequestContact(true);
                    keyboardButton.setText("Share Contact");
                    keyboardRows.add(keyboardButtons);
                    keyboardButtons.add(keyboardButton);
                    replyKeyboardMarkup.setKeyboard(keyboardRows);
                    loginEntity.setStep(2);
                    loginRepo.save(loginEntity);
                    sendMessage.setText("Please Share Your Contact");
                    sendMessage.setReplyMarkup(replyKeyboardMarkup);
                } else if (loginEntity.getStep() == 3) {
                    loginEntity.setPass1(text);
                    loginEntity.setStep(4);
                    loginEntity.setLastAction(now());
                    loginRepo.save(loginEntity);
                    sendMessage.setText("Input Your Second Password");
                } else if (loginEntity.getStep() == 4) {
                    loginEntity.setPass2(text);
                    LoginEntity save = loginRepo.save(loginEntity);
                    User user1 = walkThroughSteps(save);
                    if (user1 != null) {
                        user1.setChatId(loginEntity.getChatId());
                        User user = userRepository.save(user1);
                        loginEntity.setStep(5);
                        loginEntity.setLastAction(now());
                        user.setLogin(true);
                        userRepository.save(user);
                        sendMessage.setText("Hurmatli " + user.getFirstName() + " " + user.getLastName() + " " + user.getMiddleName() + "\n" +
                                "Siz Muvaffaqqiyatli ro'yxatdan o'tdingiz va siz xar 20 minutda eng yangi fileni olasiz");
                    } else {
                        loginRepo.delete(loginEntity);
                        sendMessage.setText("Mobile Number, First password Or Second Password Are Invalid\n\uD83D\uDE45\u200D♂️\uD83D\uDE45\u200D♂️\uD83D\uDE45\u200D♂️\uD83D\uDE45\u200D♂️\uD83D\uDE45\u200D♂️\nPLease Click /start");

                    }


                } else {
                    sendMessage.setText("Please Click /start");
                }
            } else if (message.hasContact()) {
                Contact contact = message.getContact();
                String phoneNumber = contact.getPhoneNumber();
                System.out.println(phoneNumber);
                if (phoneNumber.startsWith("+"))
                    loginEntity.setPhoneNumber(phoneNumber.substring(1));
                loginEntity.setPhoneNumber(phoneNumber);
                loginEntity.setStep(3);
                loginEntity.setLastAction(now());
                loginRepo.save(loginEntity);
                sendMessage.setText("Your Number " + phoneNumber + "\nInput You First Password:");
            }
            try {
                execute(sendMessage);
            } catch (TelegramApiException e) {
                throw new RuntimeException(e);
            }

        }
    }


    private LoginEntity getLoginEntity(Update update) {
        Long chatId = update.getMessage().getChatId();
        Optional<LoginEntity> optionalLoginEntity = loginRepo.findByChatId(chatId.toString());
        if (optionalLoginEntity.isPresent()) {
            return optionalLoginEntity.get();
        } else {
            LoginEntity loginEntity = new LoginEntity();
            loginEntity.setChatId(chatId.toString());
            return loginRepo.save(loginEntity);
        }
    }


    private User walkThroughSteps(LoginEntity loginEntity) {
        return userRepository.findByMobileNumberAndFirstPasswordAndSecondPassword(loginEntity.getPhoneNumber(), loginEntity.getPass1(), loginEntity.getPass2()).orElse(null);
    }


    @Scheduled(fixedRate = 1000 * 60 * 5)
    public void deleteUnusedLoginEntity() throws TelegramApiException {
        List<LoginEntity> all = loginRepo.findAll();
        for (LoginEntity loginEntity : all) {
            long until = LocalTime.now().until(loginEntity.getLastAction(), MINUTES);
            String chatId = loginEntity.getChatId();
            if (until < 5) {
                loginRepo.delete(loginEntity);
            }
            SendMessage sendMessage = new SendMessage();
            sendMessage.setChatId(chatId);
            sendMessage.setText("Please Click /start");
            execute(sendMessage);
        }
    }


    @Scheduled(fixedRate = 1000 * 15)
    private void getLastModifiedFile() {
        User currentUser;
        for (User user : userRepository.findAll()) {
            currentUser = user;
            if (currentUser != null) {
                System.out.println("Current user nulmas");
                if (currentUser.isLogin()) {
                    System.out.println("current user logini true");
                    java.io.File fileDirectory = new java.io.File(filePath);
                    if (fileDirectory.isDirectory()) {
                        System.out.println("Fayllarga kelfik");
                        java.io.File[] files = fileDirectory.listFiles();
                        if (files != null) {
                            java.io.File lastModified = files[0];
                            for (java.io.File value : files) {
                                System.out.println("Fayllarni aylayayapmiz");
                                if (lastModified.lastModified() < value.lastModified()) {
                                    lastModified = value;
                                }
                            }
                            System.out.println(lastModified.getName());
                            SendDocument sendDocument = new SendDocument();
                            sendDocument.setCaption("Bu Eng Oxirgi File \nnow it it time "+LocalTime.now());
                            sendDocument.setChatId(currentUser.getChatId());
                            sendDocument.setDocument(new InputFile(lastModified));


                            try {
                                execute(sendDocument);
                            } catch (TelegramApiException e) {
                                throw new RuntimeException(e);
                            }

                        }
                    }
                }
            }
        }
    }


}
