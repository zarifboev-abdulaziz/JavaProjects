package com.example.configuration;


import com.example.controller.MyBotService;
import com.example.entity.User;
import com.example.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;


@RequiredArgsConstructor
@Component
public class DataLoader implements CommandLineRunner {

    private final MyBotService myBotService;
    private final UserRepository userRepository;

    @Value("${spring.jpa.hibernate.ddl-auto}")
    private String ddl;

    @Override
    public void run(String... args) throws Exception {
        TelegramBotsApi telegramBotsApi = new TelegramBotsApi(DefaultBotSession.class);
        telegramBotsApi.registerBot(this.myBotService);

        if (ddl.equalsIgnoreCase("create") || ddl.equalsIgnoreCase("create-drop")){
            User user = new User();
            user.setFirstName("Mirkomil");
            user.setLastName("Ablayev");
            user.setMiddleName("Zafarovich");
            user.setMobileNumber("998991337742");
            user.setFirstPassword("1");
            user.setSecondPassword("1");
            userRepository.save(user);


            User user1 = new User();
            user1.setFirstName("Bahrom");
            user1.setLastName("");
            user1.setMiddleName("");
            user1.setMobileNumber("998950015675");
            user1.setFirstPassword("2");
            user1.setSecondPassword("2");
            userRepository.save(user1);

            User user3 = new User();
            user3.setFirstName("Javohir");
            user3.setLastName("");
            user3.setMiddleName("");
            user3.setMobileNumber("998997834961");
            user3.setFirstPassword("3");
            user3.setSecondPassword("3");
            userRepository.save(user3);

            User user4 = new User();
            user4.setFirstName("Hikmatillo");
            user4.setLastName("");
            user4.setMiddleName("");
            user4.setMobileNumber("998914053508");
            user4.setFirstPassword("d-doc");
            user4.setSecondPassword("darico");
            userRepository.save(user4);

        }
    }




}
