create procedure sendmoney(IN sender_id integer, IN receiver_id integer, IN amount integer)
    language plpgsql
as
$$
Begin  

UPDATE persons
SET balance = balance - amount
WHERE id = sender_id;

UPDATE persons
SET balance = balance + amount
WHERE id = receiver_id;

INSERT INTO transaction_history(senderID, receiverID, sentAmount, date)
VALUES(sendmoney.sender_id, sendmoney.receiver_id, sendmoney.amount, now());
		 
End;
$$;

alter procedure sendmoney(integer, integer, integer) owner to postgres;

